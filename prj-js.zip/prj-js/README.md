# RealEstatePro - MyManager Backoffice

Application Backoffice de Gestion Immobilière développée en **Vanilla JS**, HTML5 et CSS3.

## 🚀 Comment lancer le projet

Puisque ce projet utilise des **Modules ES6** (`import/export`), vous ne pouvez pas simplement ouvrir le fichier `index.html` directement dans le navigateur (erreur CORS). Vous devez utiliser un serveur local.

### Option 1 : Avec Node.js (Recommandé)
Si Node.js est installé, lancez simplement cette commande à la racine du projet :

```bash
npx serve .
```

Puis ouvrez l'adresse indiquée (ex: `http://localhost:3000`).

### Option 2 : Extension VS Code "Live Server"
1. Installez l'extension **Live Server** dans VS Code.
2. Faites un clic droit sur `index.html`.
3. Choisissez **Open with Live Server**.

### Option 3 : Avec Python
```bash
python -m http.server 8000
```
Ouvrez `http://localhost:8000`.

## 🔑 Connexion
- **Utilisateur** : `admin`
- **Mot de passe** : `admin`

## 🛠 Fonctionnalités

### 1. Dashboard
- Statistiques clés (KPIs)
- Graphiques financies (Revenus, Types de biens) via Chart.js

### 2. Gestion des Entités (CRUD)
- **Biens Immobiliers** : Liste, Création, Édition, Détails, Filtres.
- **Clients (Acheteurs)** : Intégration API `ReqRes`.
- **Agents** : Intégration API `JSONPlaceholder`.
- **Contrats** : Suivi des ventes et commissions.
- **Visites** : Calendrier des visites.

### 3. Fonctionnalités Avancées
- **Internationalisation (i18n)** : Français 🇫🇷, Anglais 🇬🇧, Arabe 🇸🇦 (RTL).
- **Export** : CSV et PDF (simulé).
- **Design** : Thème Premium Responsive.

## 📁 Structure du Projet
- `index.html` : Point d'entrée.
- `css/` : Styles (Variables CSS, Flexbox/Grid).
- `js/`
  - `router.js` : Gestion des routes (SPA).
  - `services/` : Store, Auth, API, i18n.
  - `pages/` : Composants des différentes vues.
  - `app.js` : Initialisation.
