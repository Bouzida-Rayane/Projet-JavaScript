import { Router } from './router.js';
import { Store } from './services/store.js';
import { I18n } from './services/i18n.js';
import { AuthService } from './services/auth.js';
import { ApiService } from './services/api.js';

class App {
    constructor() {
        this.store = new Store();
        this.i18n = new I18n();
        this.auth = new AuthService();
        this.apiService = new ApiService();
        this.router = new Router(this);

        this.init();
    }

    async init() {
        console.log('Initializing RealEstatePro...');

        // Simulating data loading
        setTimeout(() => {
            document.getElementById('loading-screen').style.display = 'none';
            this.router.resolve();
        }, 1000);
    }
}

// Start the app
window.app = new App();
