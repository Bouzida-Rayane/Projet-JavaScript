export class AuthService {
    constructor() {
        this.user = JSON.parse(localStorage.getItem('user'));
    }

    async login(username, password) {
        // Hardcoded Admin
        if (username === 'admin' && password === 'admin') {
            this.user = { username: 'admin', role: 'admin', name: 'Admin User', id: 0 };
            localStorage.setItem('user', JSON.stringify(this.user));
            return true;
        }

        // Check Agents via ApiService
        // We use window.app.apiService to avoid circular import issues if any
        if (window.app && window.app.apiService) {
            const agents = await window.app.apiService.getAgents();
            const agent = agents.find(a => (a.email === username || a.username === username) && password === 'password'); // detailed pwd check

            if (agent) {
                this.user = {
                    username: agent.email,
                    role: 'agent',
                    name: agent.name,
                    id: agent.id
                };
                localStorage.setItem('user', JSON.stringify(this.user));
                return true;
            }
        }

        return false;
    }

    logout() {
        this.user = null;
        localStorage.removeItem('user');
        window.location.hash = '#/login';
    }

    isAuthenticated() {
        return !!this.user;
    }

    isAdmin() {
        return this.user && this.user.role === 'admin';
    }
}
