export class I18n {
    constructor() {
        this.lang = localStorage.getItem('appLang') || 'fr'; // Default to French as requested by context cues or just standard
        this.dictionaries = {
            en: {
                'app.title': 'RealEstatePro Manager',
                'nav.dashboard': 'Dashboard',
                'nav.properties': 'Properties',
                'nav.clients': 'Buyers',
                'nav.agents': 'Agents',
                'nav.contracts': 'Contracts',
                'common.save': 'Save',
                'common.cancel': 'Cancel',
                'common.delete': 'Delete',
                'common.edit': 'Edit',
                'common.actions': 'Actions',
                'common.search': 'Search...',
            },
            fr: {
                'app.title': 'RealEstatePro Manager',
                'nav.dashboard': 'Tableau de bord',
                'nav.properties': 'Biens Immobiliers',
                'nav.clients': 'Clients Acheteurs',
                'nav.agents': 'Agents Immobiliers',
                'nav.contracts': 'Contrats & Ventes',
                'common.save': 'Enregistrer',
                'common.cancel': 'Annuler',
                'common.delete': 'Supprimer',
                'common.edit': 'Modifier',
                'common.actions': 'Actions',
                'common.search': 'Rechercher...',
            },
            ar: {
                'app.title': 'مدير العقارات',
                'nav.dashboard': 'لوحة القيادة',
                'nav.properties': 'العقارات',
                'nav.clients': 'العملاء',
                'nav.agents': 'الوكلاء',
                'nav.contracts': 'العقود والمبيعات',
                'common.save': 'حفظ',
                'common.cancel': 'إلغاء',
                'common.delete': 'حذف',
                'common.edit': 'تعديل',
                'common.actions': 'إجراءات',
                'common.search': 'بحث...',
            }
        };

        this.updateDirection();
    }

    t(key) {
        return this.dictionaries[this.lang][key] || key;
    }

    setLang(lang) {
        this.lang = lang;
        localStorage.setItem('appLang', lang);
        this.updateDirection();
    }

    updateDirection() {
        document.documentElement.lang = this.lang;
        if (this.lang === 'ar') {
            document.documentElement.dir = 'rtl';
        } else {
            document.documentElement.dir = 'ltr';
        }
    }
}
