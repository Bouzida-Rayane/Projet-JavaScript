export class ApiService {
    constructor() {
        this.baseUrl = '';
    }

    // Helper to get current user
    getCurrentUser() {
        return window.app?.auth?.user || null;
    }

    // Main Router for GetData (legacy support for generic calls)
    async get(endpoint) {
        if (endpoint.includes('mock/properties')) return this.getMockProperties();
        if (endpoint.includes('clients')) return this.getClients();
        if (endpoint.includes('users') && !endpoint.includes('reqres')) return this.getAgents();
        if (endpoint.includes('visits')) return this.getVisits();

        try {
            const response = await fetch(endpoint);
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }

    // --- Properties ---
    async getMockProperties() {
        const stored = localStorage.getItem('properties_data');
        if (stored) {
            this.propertiesCache = JSON.parse(stored);
            return this.propertiesCache;
        }

        try {
            const response = await fetch('data/properties.json');
            if (response.ok) {
                this.propertiesCache = await response.json();
                localStorage.setItem('properties_data', JSON.stringify(this.propertiesCache));
                return this.propertiesCache;
            }
        } catch (e) {
            console.error('Error loading properties.json:', e);
        }

        // Fallback
        this.propertiesCache = [
            { id: 1, type: 'Apartment', price: 250000, city: 'Paris', title: 'Lovely Apt Fallback' },
            { id: 2, type: 'House', price: 450000, city: 'Lyon', title: 'Family House Fallback' }
        ];
        localStorage.setItem('properties_data', JSON.stringify(this.propertiesCache));
        return this.propertiesCache;
    }

    async getPropertyById(id) {
        const properties = await this.getMockProperties();
        return properties.find(p => p.id == id);
    }

    async saveProperty(property) {
        await this.getMockProperties();
        if (property.id) {
            const index = this.propertiesCache.findIndex(p => p.id == property.id);
            if (index !== -1) this.propertiesCache[index] = { ...this.propertiesCache[index], ...property };
        } else {
            const newId = (this.propertiesCache.length > 0 ? Math.max(...this.propertiesCache.map(p => p.id)) : 0) + 1;
            this.propertiesCache.push({ ...property, id: newId });
        }
        localStorage.setItem('properties_data', JSON.stringify(this.propertiesCache));
    }

    async deleteProperty(id) {
        await this.getMockProperties();
        this.propertiesCache = this.propertiesCache.filter(p => p.id != id);
        localStorage.setItem('properties_data', JSON.stringify(this.propertiesCache));
    }

    // --- Clients ---
    async getClients() {
        const user = this.getCurrentUser();
        let clients = [];
        const stored = localStorage.getItem('clients_data');

        if (stored) {
            clients = JSON.parse(stored);
        } else {
            // Initial Seed with assigned agents
            // Assigning some to Agent 1 (John, ID 1) and some to Agent 2 (Jane, ID 2)
            try {
                const response = await fetch('https://reqres.in/api/users?per_page=6');
                if (response.ok) {
                    const data = await response.json();
                    clients = data.data.map((c, index) => ({
                        id: c.id,
                        first_name: c.first_name,
                        last_name: c.last_name,
                        email: c.email,
                        avatar: c.avatar,
                        budget: Math.floor(Math.random() * 500000) + 150000,
                        status: 'Active',
                        assigned_agent_id: index % 2 === 0 ? 1 : 2 // Evens to John(1), Odds to Jane(2)
                    }));
                }
            } catch (e) {
                // Fallback if reqres fails
                clients = [
                    { id: 1, first_name: 'George', last_name: 'Bluth', assigned_agent_id: 1, status: 'Active' },
                    { id: 2, first_name: 'Janet', last_name: 'Weaver', assigned_agent_id: 2, status: 'Active' }
                ];
            }
            localStorage.setItem('clients_data', JSON.stringify(clients));
        }

        // --- FILTERING LOGIC ---
        if (user && user.role === 'agent') {
            return clients.filter(c => c.assigned_agent_id === user.id);
        }

        return clients;
    }

    async getClientById(id) {
        // reuse getClients so filtering applies
        const clients = await this.getClients();
        return clients.find(c => c.id == id);
    }

    async saveClient(client) {
        const user = this.getCurrentUser();

        let allClients = [];
        const stored = localStorage.getItem('clients_data');
        if (stored) allClients = JSON.parse(stored);

        // Security check: if agent, can only update own client
        if (user && user.role === 'agent' && client.id) {
            const existing = allClients.find(c => c.id == client.id);
            if (existing && existing.assigned_agent_id !== user.id) {
                throw new Error("Unauthorized");
            }
            // Force assignment to self if creating/updating
            client.assigned_agent_id = user.id;
        } else if (user && user.role === 'agent' && !client.id) {
            client.assigned_agent_id = user.id;
        }

        if (client.id) {
            const index = allClients.findIndex(c => c.id == client.id);
            if (index !== -1) allClients[index] = { ...allClients[index], ...client };
        } else {
            const newId = (allClients.length > 0 ? Math.max(...allClients.map(c => c.id)) : 0) + 1;
            allClients.push({
                ...client,
                id: newId,
                avatar: client.avatar || 'https://reqres.in/img/faces/1-image.jpg'
            });
        }
        localStorage.setItem('clients_data', JSON.stringify(allClients));
    }

    // --- Agents ---
    async getAgents() {
        // Return structured mock agents including passwords for testing
        // Id 1: John, Id 2: Jane
        return [
            {
                id: 1,
                name: 'John Doe',
                email: 'john@agency.com',
                role: 'agent',
                phone: '123-456-7890',
                website: 'agency.com',
                company: { name: 'RealEstatePro' },
                address: { street: '123 Main St', city: 'Metropolis', zipcode: '12345' }
            },
            {
                id: 2,
                name: 'Jane Smith',
                email: 'jane@agency.com',
                role: 'agent',
                phone: '098-765-4321',
                website: 'agency.com',
                company: { name: 'RealEstatePro' },
                address: { street: '456 Oak Ave', city: 'Gotham', zipcode: '67890' }
            }
        ];
    }

    async getAgentById(id) {
        const agents = await this.getAgents();
        return agents.find(a => a.id == id);
    }

    // --- Visits ---
    async getVisits() {
        const user = this.getCurrentUser();
        let visits = [];
        const stored = localStorage.getItem('visits_data');

        if (stored) {
            visits = JSON.parse(stored);
        } else {
            visits = [
                { id: 1, property: 'Lovely Apt', client: 'George Bluth', date: '2023-10-15T14:30', agent: 'John Doe', agent_id: 1, status: 'Scheduled' },
                { id: 2, property: 'Family House', client: 'Janet Weaver', date: '2023-10-16T10:00', agent: 'Jane Smith', agent_id: 2, status: 'Completed' }
            ];
            localStorage.setItem('visits_data', JSON.stringify(visits));
        }

        // --- FILTERING LOGIC ---
        if (user && user.role === 'agent') {
            return visits.filter(v => v.agent_id === user.id);
        }

        return visits;
    }

    async getVisitById(id) {
        const visits = await this.getVisits();
        return visits.find(v => v.id == id);
    }

    async saveVisit(visit) {
        const user = this.getCurrentUser();
        let visits = [];
        const stored = localStorage.getItem('visits_data');
        if (stored) visits = JSON.parse(stored); // Load raw to save

        if (user && user.role === 'agent') {
            // Force assign to self
            visit.agent_id = user.id;
            visit.agent = user.name || user.username;
        }

        if (visit.id) {
            const index = visits.findIndex(v => v.id == visit.id);
            if (index !== -1) {
                // Check ownership if agent
                if (user && user.role === 'agent' && visits[index].agent_id !== user.id) {
                    throw new Error("Unauthorized");
                }
                visits[index] = { ...visits[index], ...visit };
            }
        } else {
            const newId = (visits.length > 0 ? Math.max(...visits.map(v => v.id)) : 0) + 1;
            visits.push({ ...visit, id: newId });
        }
        localStorage.setItem('visits_data', JSON.stringify(visits));
    }

    async deleteVisit(id) {
        const user = this.getCurrentUser();
        let visits = [];
        const stored = localStorage.getItem('visits_data');
        if (stored) visits = JSON.parse(stored);

        if (user && user.role === 'agent') {
            const v = visits.find(x => x.id == id);
            if (v && v.agent_id !== user.id) throw new Error("Unauthorized");
        }

        visits = visits.filter(v => v.id != id);
        localStorage.setItem('visits_data', JSON.stringify(visits));
    }

    async getMockStats() {
        const user = this.getCurrentUser();

        // Dynamic Counts
        const properties = await this.getMockProperties();
        const clients = await this.getClients();
        const contracts = await this.getContracts();

        // Calculate Revenue (Sum of Signed Contracts commission or amount)
        const signedContracts = contracts.filter(c => c.status === 'Signed');
        const revenue = signedContracts.reduce((sum, c) => sum + (c.commission || 0), 0);
        const salesCount = signedContracts.length;

        const baseStats = {
            totalProperties: properties.length,
            activeClients: clients.filter(c => c.status === 'Active').length,
            monthlyRevenue: revenue,
            salesCount: salesCount
        };

        if (user && user.role === 'agent') {
            // Agent-specific stats (already filtered by getClients/getContracts)
            return {
                totalProperties: properties.length, // visible to all
                activeClients: clients.length,
                monthlyRevenue: revenue,
                salesCount: salesCount
            };
        }
        return baseStats;
    }

    // --- Contracts ---
    async getContracts() {
        const user = this.getCurrentUser();
        let contracts = [];
        const stored = localStorage.getItem('contracts_data');

        if (stored) {
            contracts = JSON.parse(stored);
        } else {
            // Mock Data with agent_id
            contracts = Array.from({ length: 10 }, (_, i) => ({
                id: 1000 + i,
                property: `Property #${200 + i}`,
                client: `Client #${300 + i}`,
                date: new Date(2023, 5, 10 + i),
                amount: 250000 + i * 10000,
                commission: (250000 + i * 10000) * 0.05,
                status: i % 3 === 0 ? 'Signed' : 'Pending',
                agent_id: i % 2 === 0 ? 1 : 2 // John(1), Jane(2)
            }));
            localStorage.setItem('contracts_data', JSON.stringify(contracts));
        }

        if (user && user.role === 'agent') {
            return contracts.filter(c => c.agent_id === user.id);
        }
        return contracts;
    }

    async getContractById(id) {
        const contracts = await this.getContracts();
        return contracts.find(c => c.id == id);
    }

    async saveContract(contract) {
        const user = this.getCurrentUser();
        let contracts = await this.getContracts();

        // Auto assign agent if agent
        if (user && user.role === 'agent') {
            contract.agent_id = user.id;
        }

        const newId = (contracts.length > 0 ? Math.max(...contracts.map(c => c.id)) : 0) + 1;
        // Merge with new ID
        contracts.push({ ...contract, id: newId });

        // Note: we are pushing to "filtered" contracts if filtering is on? 
        // No, getContracts returns filtered list for agents.
        // But for saving we really should load ALL contracts, append, then save.
        // BUT 'contracts_data' is a simple JSON string. 
        // Let's do it right:

        const stored = localStorage.getItem('contracts_data');
        let allContracts = stored ? JSON.parse(stored) : contracts;

        // If we just pushed to 'contracts' (which might be filtered), we might miss others.
        // So let's re-push correctly.
        allContracts.push({ ...contract, id: newId, agent_id: contract.agent_id || 1 }); // Default to agent 1 if admin creates?

        localStorage.setItem('contracts_data', JSON.stringify(allContracts));
    }

    // --- Global Export ---
    async exportData() {
        // Since getClients, getVisits, getContracts are ALREADY filtered by role,
        // we just need to call them and package the result!

        const data = {
            exportedAt: new Date().toISOString(),
            user: this.getCurrentUser(),
            clients: await this.getClients(),
            visits: await this.getVisits(),
            contracts: await this.getContracts(),
            properties: await this.getMockProperties() // Everyone sees all properties usually
        };

        // Create blob and download
        const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
        const downloadAnchorNode = document.createElement('a');
        downloadAnchorNode.setAttribute("href", dataStr);
        downloadAnchorNode.setAttribute("download", "real_estate_data.json");
        document.body.appendChild(downloadAnchorNode); // required for firefox
        downloadAnchorNode.click();
        downloadAnchorNode.remove();

        return true;
    }
}
