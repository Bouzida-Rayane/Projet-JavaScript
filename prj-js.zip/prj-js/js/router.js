import { LoginPage } from './pages/login.js';
import { DashboardPage, initDashboardCharts } from './pages/dashboard.js';
import { PropertiesPage } from './pages/properties.js';
import { PropertyFormPage } from './pages/property-form.js';
import { PropertyDetailsPage } from './pages/property-details.js';
import { ClientsPage } from './pages/clients.js';
import { ClientFormPage } from './pages/client-form.js';
import { ClientDetailsPage } from './pages/client-details.js';
import { AgentsPage } from './pages/agents.js';
import { AgentDetailsPage } from './pages/agent-details.js';
import { ContractsPage } from './pages/contracts.js';
import { ContractDetailsPage } from './pages/contract-details.js';
import { ContractFormPage } from './pages/contract-form.js';
import { VisitsPage } from './pages/visits.js';
import { VisitFormPage } from './pages/visit-form.js';

export class Router {
    constructor(app) {
        this.app = app;
        this.routes = [
            { path: /^\/login$/, handler: LoginPage },
            { path: /^\/dashboard$/, handler: DashboardPage },
            { path: /^\/properties$/, handler: PropertiesPage },
            { path: /^\/properties\/new$/, handler: PropertyFormPage },
            { path: /^\/properties\/(\d+)$/, handler: PropertyDetailsPage },
            { path: /^\/properties\/(\d+)\/edit$/, handler: PropertyFormPage },
            { path: /^\/clients$/, handler: ClientsPage },
            { path: /^\/clients\/new$/, handler: ClientFormPage },
            { path: /^\/clients\/(\d+)$/, handler: ClientDetailsPage },
            { path: /^\/clients\/(\d+)\/edit$/, handler: ClientFormPage },
            { path: /^\/agents$/, handler: AgentsPage },
            { path: /^\/agents\/(\d+)$/, handler: AgentDetailsPage },
            { path: /^\/contracts$/, handler: ContractsPage },
            { path: /^\/contracts\/new$/, handler: ContractFormPage },
            { path: /^\/contracts\/(\d+)$/, handler: ContractDetailsPage },
            { path: /^\/visits$/, handler: VisitsPage },
            { path: /^\/visits\/new$/, handler: VisitFormPage },
            { path: /^\/visits\/(\d+)\/edit$/, handler: VisitFormPage },
            { path: /^\//, handler: DashboardPage } // Default
        ];

        window.addEventListener('hashchange', () => this.resolve());
        if (!window.location.hash) {
            window.location.hash = '#/dashboard';
        }
    }

    async resolve() {
        const hash = window.location.hash.slice(1) || '/dashboard';
        const path = hash.split('?')[0];

        console.log(`Navigating to ${path}`);

        if (!this.app.auth.isAuthenticated() && path !== '/login') {
            window.location.hash = '#/login';
            return;
        }

        let route = this.routes.find(r => r.path.test(path));

        const appDiv = document.getElementById('app');

        if (route) {
            const match = path.match(route.path);
            const params = match ? match.slice(1) : [];

            if (path === '/login') {
                appDiv.innerHTML = await route.handler(...params);
            } else {
                appDiv.innerHTML = `
                    <div class="main-layout">
                        <aside class="sidebar" id="sidebar">
                            ${this.renderSidebar(path)}
                        </aside>
                        <div class="content-wrapper">
                            <nav class="navbar">
                                ${this.renderNavbar()}
                            </nav>
                            <main class="main-content">
                                ${await route.handler(...params)}
                            </main>
                        </div>
                    </div>
                 `;
                this.attachGlobalListeners();

                if (path === '/dashboard') {
                    setTimeout(initDashboardCharts, 100);
                }
            }
        } else {
            appDiv.innerHTML = '<h1>404 - Page Not Found</h1>';
        }
    }

    renderSidebar(currentPath) {
        const isActive = (p) => currentPath.startsWith(p) ? 'active' : '';
        const isAdmin = this.app.auth.isAdmin();

        return `
            <div class="logo">
                <i class="fa-solid fa-building-user"></i> <span>RealEstatePro</span>
            </div>
            <ul class="nav-links">
                <li class="${isActive('/dashboard')}">
                    <a href="#/dashboard"><i class="fa-solid fa-chart-pie"></i> ${this.app.i18n.t('nav.dashboard')}</a>
                </li>
                <li class="${isActive('/properties')}">
                    <a href="#/properties"><i class="fa-solid fa-house"></i> ${this.app.i18n.t('nav.properties')}</a>
                </li>
                <li class="${isActive('/clients')}">
                    <a href="#/clients"><i class="fa-solid fa-users"></i> ${this.app.i18n.t('nav.clients')}</a>
                </li>
                ${isAdmin ? `
                <li class="${isActive('/agents')}">
                    <a href="#/agents"><i class="fa-solid fa-user-tie"></i> ${this.app.i18n.t('nav.agents')}</a>
                </li>
                ` : ''}
                <li class="${isActive('/visits')}">
                    <a href="#/visits"><i class="fa-solid fa-calendar-check"></i> Visits</a>
                </li>
                 <li class="${isActive('/contracts')}">
                    <a href="#/contracts"><i class="fa-solid fa-file-contract"></i> ${this.app.i18n.t('nav.contracts')}</a>
                </li>
            </ul>
        `;
    }

    renderNavbar() {
        const userName = this.app.auth.user ? this.app.auth.user.name : 'Guest';
        const userLabel = this.app.auth.user && this.app.auth.isAdmin() ? 'Admin' : 'Agent';

        return `
            <div class="nav-left">
                <button id="sidebar-toggle" style="background:none; border:none; cursor:pointer; font-size:1.2rem; margin-right:1rem;"><i class="fa-solid fa-bars"></i></button>
                <h2>${this.app.i18n.t('app.title')}</h2>
            </div>
            <div class="nav-right">
                <select id="lang-switcher" style="padding: 6px; border-radius: 4px; border: 1px solid #ddd;">
                    <option value="en" ${this.app.i18n.lang === 'en' ? 'selected' : ''}>🇬🇧 EN</option>
                    <option value="fr" ${this.app.i18n.lang === 'fr' ? 'selected' : ''}>🇫🇷 FR</option>
                    <option value="ar" ${this.app.i18n.lang === 'ar' ? 'selected' : ''}>🇸🇦 AR</option>
                </select>
                <div class="user-profile" style="font-weight: 500;">
                    <span>${userName} <small>(${userLabel})</small></span>
                    <button id="logout-btn" class="icon-btn" style="margin-left: 10px;"><i class="fa-solid fa-right-from-bracket"></i></button>
                </div>
            </div>
        `;
    }

    attachGlobalListeners() {
        const langSelect = document.getElementById('lang-switcher');
        if (langSelect) {
            langSelect.addEventListener('change', (e) => {
                this.app.i18n.setLang(e.target.value);
                this.resolve();
            });
        }

        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                this.app.auth.logout();
            });
        }

        const sidebarToggle = document.getElementById('sidebar-toggle');
        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', () => {
                const sidebar = document.getElementById('sidebar');
                if (sidebar) {
                    // Simple toggle implementation
                    // In a real app we'd toggle a css class on the parent
                    if (sidebar.style.display === 'none') {
                        sidebar.style.display = 'flex';
                    } else {
                        sidebar.style.display = 'none';
                    }
                }
            });
        }
    }
}
