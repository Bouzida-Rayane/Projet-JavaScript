export const formatCurrency = (amount, currency = 'EUR', locale = 'fr-FR') => {
    return new Intl.NumberFormat(locale, { style: 'currency', currency }).format(amount);
};

export const formatDate = (dateString, locale = 'fr-FR') => {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString(locale);
};

export const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// --- Table Utilities ---

export const exportToCSV = (data, filename) => {
    if (!data || !data.length) return;
    const separator = ',';
    const keys = Object.keys(data[0]);
    const csvContent =
        keys.join(separator) +
        '\n' +
        data.map(row => {
            return keys.map(k => {
                let cell = row[k] === null || row[k] === undefined ? '' : row[k];
                cell = cell instanceof Date ? cell.toISOString() : cell.toString();
                cell = cell.replace(/"/g, '""');
                if (cell.search(/("|,|\n)/g) >= 0) cell = `"${cell}"`;
                return cell;
            }).join(separator);
        }).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};

export const filterData = (data, query, fields) => {
    if (!query) return data;
    const lowerQuery = query.toLowerCase();
    return data.filter(item =>
        fields.some(field => {
            const val = item[field];
            return val && val.toString().toLowerCase().includes(lowerQuery);
        })
    );
};

export const sortData = (data, key, direction = 'asc') => {
    if (!key) return data;
    const sorted = [...data].sort((a, b) => {
        const aVal = a[key] || '';
        const bVal = b[key] || '';
        if (aVal < bVal) return -1;
        if (aVal > bVal) return 1;
        return 0;
    });
    return direction === 'desc' ? sorted.reverse() : sorted;
};

export const paginateData = (data, page, pageSize) => {
    const start = (page - 1) * pageSize;
    return data.slice(start, start + pageSize);
};
