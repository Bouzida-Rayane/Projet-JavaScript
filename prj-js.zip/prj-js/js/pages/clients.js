import { formatCurrency, filterData, sortData, paginateData, exportToCSV } from '../utils.js';

export const ClientsPage = async () => {
    const allClients = await window.app.apiService.getClients();

    let state = {
        query: '',
        sortKey: 'first_name',
        sortDir: 'asc',
        currentPage: 1,
        pageSize: 5
    };

    const renderTableRows = () => {
        let data = filterData(allClients, state.query, ['first_name', 'last_name', 'email']);
        data = sortData(data, state.sortKey, state.sortDir);

        const totalPages = Math.ceil(data.length / state.pageSize) || 1;
        if (state.currentPage > totalPages) state.currentPage = 1;

        const paginatedData = paginateData(data, state.currentPage, state.pageSize);
        const tbody = document.getElementById('clients-tbody');

        if (tbody) {
            tbody.innerHTML = paginatedData.map(c => `
                <tr>
                    <td><img src="${c.avatar}" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;"></td>
                    <td>${c.first_name || ''} ${c.last_name || ''}</td>
                    <td>${c.email}</td>
                    <td>${formatCurrency(c.budget)}</td>
                    <td><span style="padding: 4px 8px; background: ${c.status === 'Active' ? '#e8f5e9' : '#fff3e0'}; color: ${c.status === 'Active' ? '#2e7d32' : '#ef6c00'}; border-radius: 12px; font-size: 0.85rem;">${c.status}</span></td>
                    <td>
                        <button class="icon-btn" onclick="window.location.hash='#/clients/${c.id}'" title="View"><i class="fa-solid fa-eye"></i></button>
                        <button class="icon-btn" onclick="window.location.hash='#/clients/${c.id}/edit'" title="Edit"><i class="fa-solid fa-pen-to-square"></i></button>
                    </td>
                </tr>
            `).join('');
        }

        const paginationContainer = document.getElementById('pagination-controls');
        if (paginationContainer) {
            paginationContainer.innerHTML = `
                <button class="icon-btn" id="prev-page" ${state.currentPage === 1 ? 'disabled' : ''}><i class="fa-solid fa-chevron-left"></i></button>
                <span style="margin: 0 10px;">Page ${state.currentPage} of ${totalPages}</span>
                <button class="icon-btn" id="next-page" ${state.currentPage === totalPages ? 'disabled' : ''}><i class="fa-solid fa-chevron-right"></i></button>
            `;
            document.getElementById('prev-page').onclick = () => { if (state.currentPage > 1) { state.currentPage--; renderTableRows(); } };
            document.getElementById('next-page').onclick = () => { if (state.currentPage < totalPages) { state.currentPage++; renderTableRows(); } };
        }
    };

    setTimeout(() => {
        const searchInput = document.getElementById('search-input');
        const sortSelect = document.getElementById('sort-select');
        const exportBtn = document.getElementById('export-btn');

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                state.query = e.target.value;
                state.currentPage = 1;
                renderTableRows();
            });
        }

        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                const parts = e.target.value.split('-');
                if (parts.length === 2) {
                    state.sortKey = parts[0];
                    state.sortDir = parts[1];
                }
                renderTableRows();
            });
        }

        if (exportBtn) {
            exportBtn.onclick = () => {
                let data = filterData(allClients, state.query, ['first_name', 'last_name', 'email']);
                data = sortData(data, state.sortKey, state.sortDir);
                exportToCSV(data, 'clients_export.csv');
            };
        }

        renderTableRows();
    }, 0);

    return `
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <h1>${window.app.i18n.t('nav.clients')}</h1>
            <div style="display: flex; gap: 10px;">
                <button class="btn-secondary" id="export-btn">
                    <i class="fa-solid fa-file-csv"></i> Export CSV
                </button>
                <button class="btn-primary" onclick="window.location.hash='#/clients/new'">
                    <i class="fa-solid fa-plus"></i> New Client
                </button>
            </div>
        </div>

        <div class="filters-bar" style="background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; flex-wrap: wrap;">
             <input type="text" id="search-input" placeholder="Search name, email..." style="padding: 8px; border: 1px solid #ddd; border-radius: 4px; flex: 1;">
             <select id="sort-select" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                <option value="last_name-asc">Name: A-Z</option>
                <option value="last_name-desc">Name: Z-A</option>
                <option value="budget-asc">Budget: Low to High</option>
                <option value="budget-desc">Budget: High to Low</option>
            </select>
        </div>
        
        <div class="table-container animate-fade-in">
            <table>
                <thead>
                    <tr>
                        <th>Avatar</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Budget (Est.)</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="clients-tbody">
                </tbody>
            </table>
             <div class="pagination" id="pagination-controls" style="display: flex; justify-content: flex-end; padding: 1rem; gap: 0.5rem; align-items: center;">
            </div>
        </div>
    `;
};
