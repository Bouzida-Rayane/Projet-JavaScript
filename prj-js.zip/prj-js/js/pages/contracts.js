import { formatCurrency, formatDate, filterData, sortData, paginateData, exportToCSV } from '../utils.js';

export const ContractsPage = async () => {
    const allContracts = await window.app.apiService.getContracts();

    let state = {
        query: '',
        statusFilter: '',
        sortKey: 'date',
        sortDir: 'desc',
        currentPage: 1,
        pageSize: 5
    };

    const renderTableRows = () => {
        let data = filterData(allContracts, state.query, ['property', 'client', 'id']);
        if (state.statusFilter) {
            data = data.filter(c => c.status === state.statusFilter);
        }
        data = sortData(data, state.sortKey, state.sortDir);

        const totalPages = Math.ceil(data.length / state.pageSize) || 1;
        if (state.currentPage > totalPages) state.currentPage = 1;

        const paginatedData = paginateData(data, state.currentPage, state.pageSize);
        const tbody = document.getElementById('contracts-tbody');

        if (tbody) {
            tbody.innerHTML = paginatedData.map(c => `
                <tr>
                    <td>#${c.id}</td>
                    <td>${c.property}</td>
                    <td>${c.client}</td>
                    <td>${formatDate(c.date)}</td>
                    <td>${formatCurrency(c.amount)}</td>
                    <td style="color: #27ae60; font-weight: 500;">+${formatCurrency(c.commission)}</td>
                    <td><span style="padding: 4px 8px; background: ${c.status === 'Signed' ? '#e8f5e9' : '#fff3e0'}; color: ${c.status === 'Signed' ? '#2e7d32' : '#ef6c00'}; border-radius: 12px; font-size: 0.85rem;">${c.status}</span></td>
                    <td>
                        <button class="icon-btn" onclick="window.location.hash='#/contracts/${c.id}'" title="View"><i class="fa-solid fa-eye"></i></button>
                        <button class="icon-btn" onclick="alert('Contract #${c.id} downloaded!')" title="Download"><i class="fa-solid fa-download"></i></button>
                    </td>
                </tr>
            `).join('');
        }

        const paginationContainer = document.getElementById('pagination-controls');
        if (paginationContainer) {
            paginationContainer.innerHTML = `
                <button class="icon-btn" id="prev-page" ${state.currentPage === 1 ? 'disabled' : ''}><i class="fa-solid fa-chevron-left"></i></button>
                <span style="margin: 0 10px;">Page ${state.currentPage} of ${totalPages}</span>
                <button class="icon-btn" id="next-page" ${state.currentPage === totalPages ? 'disabled' : ''}><i class="fa-solid fa-chevron-right"></i></button>
            `;
            document.getElementById('prev-page').onclick = () => { if (state.currentPage > 1) { state.currentPage--; renderTableRows(); } };
            document.getElementById('next-page').onclick = () => { if (state.currentPage < totalPages) { state.currentPage++; renderTableRows(); } };
        }
    };

    setTimeout(() => {
        const searchInput = document.getElementById('search-input');
        const statusSelect = document.getElementById('status-select');
        const sortSelect = document.getElementById('sort-select');
        const exportBtn = document.getElementById('export-btn');

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                state.query = e.target.value;
                state.currentPage = 1;
                renderTableRows();
            });
        }
        if (statusSelect) {
            statusSelect.addEventListener('change', (e) => {
                state.statusFilter = e.target.value;
                state.currentPage = 1;
                renderTableRows();
            });
        }
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                const parts = e.target.value.split('-');
                if (parts.length === 2) {
                    state.sortKey = parts[0];
                    state.sortDir = parts[1];
                }
                renderTableRows();
            });
        }
        if (exportBtn) {
            exportBtn.onclick = () => {
                let data = filterData(allContracts, state.query, ['property', 'client', 'id']);
                if (state.statusFilter) data = data.filter(c => c.status === state.statusFilter);
                data = sortData(data, state.sortKey, state.sortDir);
                exportToCSV(data, 'contracts_export.csv');
            };
        }

        renderTableRows();
    }, 0);

    return `
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <h1>${window.app.i18n.t('nav.contracts')}</h1>
            <div style="display: flex; gap: 10px;">
                <button class="btn-secondary" id="export-btn">
                    <i class="fa-solid fa-file-csv"></i> Export CSV
                </button>
                <button class="btn-primary" onclick="window.location.hash='#/contracts/new'">
                    <i class="fa-solid fa-file-signature"></i> New Contract
                </button>
            </div>
        </div>
        
        <div class="filters-bar" style="background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; flex-wrap: wrap;">
            <input type="text" id="search-input" placeholder="Search client, property..." style="padding: 8px; border: 1px solid #ddd; border-radius: 4px; flex: 1;">
            <select id="status-select" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                <option value="">All Statuses</option>
                <option value="Signed">Signed</option>
                <option value="Pending">Pending</option>
            </select>
            <select id="sort-select" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                <option value="date-desc">Date: Newest</option>
                <option value="date-asc">Date: Oldest</option>
                <option value="amount-desc">Amount: High to Low</option>
            </select>
        </div>

        <div class="table-container animate-fade-in">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Property</th>
                        <th>Client</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Commission</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="contracts-tbody">
                </tbody>
            </table>
             <div class="pagination" id="pagination-controls" style="display: flex; justify-content: flex-end; padding: 1rem; gap: 0.5rem; align-items: center;">
            </div>
        </div>
    `;
};
