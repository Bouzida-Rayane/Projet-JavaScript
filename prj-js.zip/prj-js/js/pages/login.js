export const LoginPage = async () => {
    return `
        <div class="login-container">
            <div class="login-card animate-fade-in">
                <div class="logo" style="font-size: 2rem; color: var(--primary-color); margin-bottom: 1rem;">
                    <i class="fa-solid fa-building-user"></i>
                </div>
                <h1>Welcome Back</h1>
                <form id="login-form">
                    <div class="form-group">
                        <label>Username (admin or john@agency.com)</label>
                        <input type="text" id="username" placeholder="admin" value="admin">
                    </div>
                    <div class="form-group">
                        <label>Password (admin or password)</label>
                        <input type="password" id="password" placeholder="admin" value="admin">
                    </div>
                    <button type="submit" class="btn-primary" style="width: 100%">Sign In</button>
                    <p id="error-msg" style="color: red; margin-top: 1rem; display: none;">Invalid credentials</p>
                </form>
            </div>
        </div>
    `;
};

// Listen for submission - this is a bit tricky with innerHTML injection
// We'll attach the listener in the Router or App after rendering
setTimeout(() => {
    document.addEventListener('submit', async (e) => {
        if (e.target && e.target.id === 'login-form') {
            e.preventDefault();
            const username = e.target.username.value;
            const password = e.target.password.value;

            if (await window.app.auth.login(username, password)) {
                window.location.hash = '#/dashboard';
            } else {
                document.getElementById('error-msg').style.display = 'block';
            }
        }
    });
}, 0);
