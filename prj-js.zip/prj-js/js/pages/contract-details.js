import { formatCurrency, formatDate } from '../utils.js';

export const ContractDetailsPage = async (id) => {
    // Mock Fetch Contract by finding it in the list (since we don't have a getContractById yet, we'll simulate or add it)
    let contract = { id: id, property: 'Simulated Property', client: 'Simulated Client', date: new Date(), amount: 250000, commission: 12500, status: 'Signed', terms: 'Standard contract terms apply. Valid for 30 days.' };

    // Ideally we would fetch from ApiService, let's look for it in the mock list generator or store
    // For now, let's keep it simple and static/simulated for the ID, or implement getContractById in ApiService

    return `
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
             <div>
                <a href="#/contracts" style="text-decoration: none; color: var(--text-muted); display: inline-flex; align-items: center; gap: 5px; margin-bottom: 10px;">
                    <i class="fa-solid fa-arrow-left"></i> Back to contracts
                </a>
                <h1>Contract #${id}</h1>
            </div>
            <button class="btn-primary" onclick="alert('Contract PDF downloaded!')">
                <i class="fa-solid fa-file-pdf"></i> Download PDF
            </button>
        </div>

        <div class="card animate-fade-in" style="background: white; padding: 2rem; border-radius: 12px; max-width: 800px;">
            <div style="display: flex; justify-content: space-between; border-bottom: 1px solid #eee; padding-bottom: 2rem; margin-bottom: 2rem;">
                <div>
                    <h3 style="color: var(--text-muted); font-size: 0.9rem; text-transform: uppercase;">Property</h3>
                    <div style="font-size: 1.2rem; font-weight: 500;">${contract.property}</div>
                </div>
                 <div>
                    <h3 style="color: var(--text-muted); font-size: 0.9rem; text-transform: uppercase;">Client</h3>
                    <div style="font-size: 1.2rem; font-weight: 500;">${contract.client}</div>
                </div>
                 <div>
                    <h3 style="color: var(--text-muted); font-size: 0.9rem; text-transform: uppercase;">Date</h3>
                    <div style="font-size: 1.2rem; font-weight: 500;">${formatDate(contract.date)}</div>
                </div>
            </div>
            
            <div style="background: #f8f9fa; padding: 1.5rem; border-radius: 8px; margin-bottom: 2rem;">
                <h3 style="margin-bottom: 1rem;">Financials</h3>
                <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                    <span>Sale Amount</span>
                    <strong>${formatCurrency(contract.amount)}</strong>
                </div>
                <div style="display: flex; justify-content: space-between; color: var(--secondary-color);">
                    <span>Agency Commission (5%)</span>
                    <strong>${formatCurrency(contract.commission)}</strong>
                </div>
            </div>

            <div>
                <h3 style="margin-bottom: 0.5rem;">Terms & Conditions</h3>
                <p style="color: var(--text-muted); line-height: 1.6;">
                    ${contract.terms}
                    <br><br>
                    This document certifies the agreement between the parties mentioned above.
                </p>
            </div>
        </div>
    `;
};
