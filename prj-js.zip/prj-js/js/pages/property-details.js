import { formatCurrency } from '../utils.js';

export const PropertyDetailsPage = async (id) => {
    // Mock Fetch
    const property = { id: id, title: 'Lovely Apt', type: 'Apartment', price: 250000, city: 'London', description: 'This is a mocked description for the property. It features 2 bedrooms and a large living room close to the city center.', items: ['Balcony', 'Parking', 'Concierge'] };

    return `
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <div>
                <a href="#/properties" style="text-decoration: none; color: var(--text-muted); display: inline-flex; align-items: center; gap: 5px; margin-bottom: 10px;">
                    <i class="fa-solid fa-arrow-left"></i> Back to properties
                </a>
                <h1>${property.title}</h1>
            </div>
            <button class="btn-primary" onclick="alert('PDF Exported!')">
                <i class="fa-solid fa-file-pdf"></i> Export PDF
            </button>
        </div>

        <div class="details-grid" style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
            <!-- Main Info -->
            <div class="card animate-fade-in" style="background: white; padding: 2rem; border-radius: 12px;">
                <div style="width: 100%; height: 300px; background: #eee; border-radius: 8px; margin-bottom: 2rem; display: flex; align-items: center; justify-content: center; color: #999;">
                    <i class="fa-solid fa-image" style="font-size: 3rem;"></i>
                </div>
                
                <h3>Description</h3>
                <p style="color: var(--text-color); line-height: 1.6;">${property.description}</p>
                
                <h3 style="margin-top: 2rem;">Features</h3>
                <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                    ${property.items.map(i => `<span style="background: #f4f7f6; padding: 6px 12px; border-radius: 20px;">${i}</span>`).join('')}
                </div>
            </div>

            <!-- Sidebar Info -->
            <div class="sidebar-info" style="display: flex; flex-direction: column; gap: 1.5rem;">
                <div class="card" style="background: white; padding: 1.5rem; border-radius: 12px;">
                    <div style="color: var(--text-muted); font-size: 0.9rem;">Price</div>
                    <div style="font-size: 2rem; font-weight: 700; color: var(--primary-color);">${formatCurrency(property.price)}</div>
                </div>

                <div class="card" style="background: white; padding: 1.5rem; border-radius: 12px;">
                    <div style="color: var(--text-muted); font-size: 0.9rem;">Location</div>
                    <div style="font-size: 1.2rem; font-weight: 500; margin-top: 0.5rem;">
                        <i class="fa-solid fa-location-dot" style="color: var(--secondary-color);"></i> ${property.city}
                    </div>
                </div>
                
                 <div class="card" style="background: white; padding: 1.5rem; border-radius: 12px;">
                     <button class="btn-primary" style="width: 100%; margin-bottom: 1rem;" onclick="window.location.hash='#/properties/${id}/edit'">Edit Property</button>
                     <button class="btn-secondary" style="width: 100%; padding: 10px; background: #ffebee; color: #c0392b; border: none; border-radius: 6px; cursor: pointer;">Delete Property</button>
                </div>
            </div>
        </div>
    `;
};
