export const ClientFormPage = async (id) => {
    const isEdit = !!id;
    let client = { first_name: '', last_name: '', email: '', budget: 200000, status: 'Active' };

    if (isEdit) {
        client = await window.app.apiService.getClientById(id) || client;
    }

    return `
        <div class="page-header" style="margin-bottom: 2rem;">
            <h1>${isEdit ? 'Edit Client' : 'New Client'}</h1>
            <a href="#/clients" style="text-decoration: none; color: var(--text-muted);"><i class="fa-solid fa-arrow-left"></i> Back to list</a>
        </div>

        <div class="card animate-fade-in" style="background: white; padding: 2rem; border-radius: 12px; max-width: 800px;">
            <form id="client-form">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label>First Name</label>
                        <input type="text" name="first_name" value="${client.first_name}" required>
                    </div>
                    <div class="form-group">
                        <label>Last Name</label>
                        <input type="text" name="last_name" value="${client.last_name}" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="${client.email}" required>
                </div>
                
                <div class="form-group">
                    <label>Budget (Est.)</label>
                    <input type="number" name="budget" value="${client.budget}" required>
                </div>
                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="Active" ${client.status === 'Active' ? 'selected' : ''}>Active</option>
                        <option value="Pending" ${client.status === 'Pending' ? 'selected' : ''}>Pending</option>
                        <option value="Inactive" ${client.status === 'Inactive' ? 'selected' : ''}>Inactive</option>
                    </select>
                </div>

                <div class="form-actions" style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button type="submit" class="btn-primary">${window.app.i18n.t('common.save')}</button>
                    <button type="button" class="btn-secondary" onclick="window.history.back()" style="padding: 10px 20px; border: 1px solid var(--border-color); background: white; border-radius: 6px; cursor: pointer;">${window.app.i18n.t('common.cancel')}</button>
                </div>
            </form>
        </div>
    `;
};

// Handle Form Submission
setTimeout(() => {
    document.addEventListener('submit', async (e) => {
        if (e.target && e.target.id === 'client-form') {
            e.preventDefault();
            const form = e.target;

            const client = {
                id: window.location.hash.includes('edit') ? window.location.hash.split('/')[2] : null,
                first_name: form.querySelector('input[name="first_name"]').value,
                last_name: form.querySelector('input[name="last_name"]').value,
                email: form.querySelector('input[name="email"]').value,
                budget: Number(form.querySelector('input[name="budget"]').value),
                status: form.querySelector('select[name="status"]').value,
            };

            await window.app.apiService.saveClient(client);
            window.location.hash = '#/clients';
        }
    });
}, 0);
