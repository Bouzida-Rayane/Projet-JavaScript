import { formatDate, filterData, sortData, paginateData, exportToCSV } from '../utils.js';

export const VisitsPage = async () => {
    const allVisits = await window.app.apiService.getVisits();

    let state = {
        query: '',
        statusFilter: '',
        sortKey: 'date',
        sortDir: 'desc',
        currentPage: 1,
        pageSize: 6
    };

    const renderGrid = () => {
        let data = filterData(allVisits, state.query, ['property', 'client', 'agent']);
        if (state.statusFilter) {
            data = data.filter(v => v.status === state.statusFilter);
        }
        data = sortData(data, state.sortKey, state.sortDir);

        const totalPages = Math.ceil(data.length / state.pageSize) || 1;
        if (state.currentPage > totalPages) state.currentPage = 1;

        const paginatedData = paginateData(data, state.currentPage, state.pageSize);
        const container = document.getElementById('visits-grid');

        if (container) {
            container.innerHTML = paginatedData.map(v => `
                <div class="card animate-fade-in" style="background: white; padding: 1.5rem; border-radius: 12px; border-left: 5px solid ${v.status === 'Completed' ? '#27ae60' : '#f39c12'};">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 1rem;">
                        <span style="font-weight: 700; color: var(--primary-color);">Visit #${v.id}</span>
                        <span style="font-size: 0.8rem; color: var(--text-muted);">${v.date ? formatDate(v.date) : 'TBD'}</span>
                    </div>
                    <h3 style="margin-bottom: 0.5rem;">${v.property}</h3>
                    <p style="margin-bottom: 0.5rem; color: var(--text-muted);"><i class="fa-solid fa-user"></i> ${v.client}</p>
                    <p style="margin-bottom: 1rem; color: var(--text-muted);"><i class="fa-solid fa-user-tie"></i> ${v.agent}</p>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
                        <span style="padding: 4px 8px; background: #f4f6f7; border-radius: 4px; font-size: 0.85rem;">${v.status}</span>
                        <div>
                             <button class="icon-btn" onclick="window.location.hash='#/visits/${v.id}/edit'"><i class="fa-solid fa-pen"></i></button>
                             <button class="icon-btn delete-btn" data-id="${v.id}" style="color: #c0392b;"><i class="fa-solid fa-trash"></i></button>
                        </div>
                    </div>
                </div>
            `).join('');

            // Re-attach delete listeners
            container.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = e.target.closest('button').dataset.id;
                    if (confirm('Delete visit?')) {
                        window.app.apiService.deleteVisit(id).then(() => window.app.router.resolve());
                    }
                });
            });
        }

        const paginationContainer = document.getElementById('pagination-controls');
        if (paginationContainer) {
            paginationContainer.innerHTML = `
                <button class="icon-btn" id="prev-page" ${state.currentPage === 1 ? 'disabled' : ''}><i class="fa-solid fa-chevron-left"></i></button>
                <span style="margin: 0 10px;">Page ${state.currentPage} of ${totalPages}</span>
                <button class="icon-btn" id="next-page" ${state.currentPage === totalPages ? 'disabled' : ''}><i class="fa-solid fa-chevron-right"></i></button>
            `;
            document.getElementById('prev-page').onclick = () => { if (state.currentPage > 1) { state.currentPage--; renderGrid(); } };
            document.getElementById('next-page').onclick = () => { if (state.currentPage < totalPages) { state.currentPage++; renderGrid(); } };
        }
    };

    setTimeout(() => {
        const searchInput = document.getElementById('search-input');
        const statusSelect = document.getElementById('status-select');
        const sortSelect = document.getElementById('sort-select');
        const exportBtn = document.getElementById('export-btn');

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                state.query = e.target.value;
                state.currentPage = 1;
                renderGrid();
            });
        }
        if (statusSelect) {
            statusSelect.addEventListener('change', (e) => {
                state.statusFilter = e.target.value;
                state.currentPage = 1;
                renderGrid();
            });
        }
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                const parts = e.target.value.split('-');
                if (parts.length === 2) {
                    state.sortKey = parts[0];
                    state.sortDir = parts[1];
                }
                renderGrid();
            });
        }
        if (exportBtn) {
            exportBtn.onclick = () => {
                let data = filterData(allVisits, state.query, ['property', 'client', 'agent']);
                if (state.statusFilter) data = data.filter(v => v.status === state.statusFilter);
                data = sortData(data, state.sortKey, state.sortDir);
                exportToCSV(data, 'visits_export.csv');
            };
        }

        renderGrid();
    }, 0);

    return `
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <h1>Scheduled Visits</h1>
            <div style="display: flex; gap: 10px;">
                <button class="btn-secondary" id="export-btn">
                    <i class="fa-solid fa-file-csv"></i> Export CSV
                </button>
                <button class="btn-primary" onclick="window.location.hash='#/visits/new'">
                    <i class="fa-solid fa-calendar-plus"></i> Schedule Visit
                </button>
            </div>
        </div>
        
        <div class="filters-bar" style="background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; flex-wrap: wrap;">
            <input type="text" id="search-input" placeholder="Search property, client..." style="padding: 8px; border: 1px solid #ddd; border-radius: 4px; flex: 1;">
            <select id="status-select" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                <option value="">All Statuses</option>
                <option value="Scheduled">Scheduled</option>
                <option value="Completed">Completed</option>
            </select>
            <select id="sort-select" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                <option value="date-desc">Date: Newest</option>
                <option value="date-asc">Date: Oldest</option>
            </select>
        </div>

        <div id="visits-grid" class="grid-container" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1rem;">
           <!-- Grid Items Injected via JS -->
        </div>

        <div class="pagination" id="pagination-controls" style="display: flex; justify-content: flex-end; padding: 1rem; gap: 0.5rem; align-items: center; margin-top: 1rem;">
             <!-- Controls injected by JS -->
        </div>
    `;
};
