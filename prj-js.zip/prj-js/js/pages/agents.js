import { filterData, sortData, paginateData, exportToCSV } from '../utils.js';

export const AgentsPage = async () => {
    const allAgents = await window.app.apiService.getAgents();

    let state = {
        query: '',
        sortKey: 'name',
        sortDir: 'asc',
        currentPage: 1,
        pageSize: 6 // Cards per page
    };

    const renderGrid = () => {
        let data = filterData(allAgents, state.query, ['name', 'email']);
        data = sortData(data, state.sortKey, state.sortDir);

        const totalPages = Math.ceil(data.length / state.pageSize) || 1;
        if (state.currentPage > totalPages) state.currentPage = 1;

        const paginatedData = paginateData(data, state.currentPage, state.pageSize);
        const container = document.getElementById('agents-grid');

        if (container) {
            container.innerHTML = paginatedData.map(agent => `
                <div class="card animate-fade-in" style="background: white; padding: 1.5rem; border-radius: 12px; border: 1px solid var(--border-color);">
                    <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
                        <div style="width: 50px; height: 50px; background: var(--primary-color); color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 1.2rem;">
                            ${agent.name.charAt(0)}
                        </div>
                        <div>
                            <h3 style="margin-bottom: 0.25rem;">${agent.name}</h3>
                            <span style="font-size: 0.85rem; color: var(--text-muted);">${agent.company.name}</span>
                        </div>
                    </div>
                    <div style="margin-bottom: 0.5rem;"><i class="fa-solid fa-envelope" style="width: 20px; color: var(--text-muted);"></i> ${agent.email}</div>
                    <div style="margin-bottom: 0.5rem;"><i class="fa-solid fa-phone" style="width: 20px; color: var(--text-muted);"></i> ${agent.phone}</div>
                    <div style="margin-bottom: 1rem;"><i class="fa-solid fa-globe" style="width: 20px; color: var(--text-muted);"></i> ${agent.website}</div>
                    
                    <div style="border-top: 1px solid #eee; padding-top: 1rem; display: flex; gap: 1rem;">
                        <button class="btn-primary" style="flex: 1; font-size: 0.9rem;" onclick="window.location.hash='#/agents/${agent.id}'">View Profile</button>
                    </div>
                </div>
            `).join('');
        }

        const paginationContainer = document.getElementById('pagination-controls');
        if (paginationContainer) {
            paginationContainer.innerHTML = `
                <button class="icon-btn" id="prev-page" ${state.currentPage === 1 ? 'disabled' : ''}><i class="fa-solid fa-chevron-left"></i></button>
                <span style="margin: 0 10px;">Page ${state.currentPage} of ${totalPages}</span>
                <button class="icon-btn" id="next-page" ${state.currentPage === totalPages ? 'disabled' : ''}><i class="fa-solid fa-chevron-right"></i></button>
            `;
            document.getElementById('prev-page').onclick = () => { if (state.currentPage > 1) { state.currentPage--; renderGrid(); } };
            document.getElementById('next-page').onclick = () => { if (state.currentPage < totalPages) { state.currentPage++; renderGrid(); } };
        }
    };

    setTimeout(() => {
        const searchInput = document.getElementById('search-input');
        const sortSelect = document.getElementById('sort-select');
        const exportBtn = document.getElementById('export-btn');

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                state.query = e.target.value;
                state.currentPage = 1;
                renderGrid();
            });
        }
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                const parts = e.target.value.split('-');
                if (parts.length === 2) {
                    state.sortKey = parts[0];
                    state.sortDir = parts[1];
                }
                renderGrid();
            });
        }
        if (exportBtn) {
            exportBtn.onclick = () => {
                let data = filterData(allAgents, state.query, ['name', 'email']);
                data = sortData(data, state.sortKey, state.sortDir);
                exportToCSV(data, 'agents_export.csv');
            };
        }

        renderGrid();
    }, 0);

    return `
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <h1>${window.app.i18n.t('nav.agents')}</h1>
            <button class="btn-secondary" id="export-btn">
                <i class="fa-solid fa-file-csv"></i> Export CSV
            </button>
        </div>
        
        <div class="filters-bar" style="background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; flex-wrap: wrap;">
            <input type="text" id="search-input" placeholder="Search agent name..." style="padding: 8px; border: 1px solid #ddd; border-radius: 4px; flex: 1;">
            <select id="sort-select" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                <option value="name-asc">Name: A-Z</option>
                <option value="name-desc">Name: Z-A</option>
            </select>
        </div>

        <div id="agents-grid" class="grid-container" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem;">
            <!-- Grid Items Injected via JS -->
        </div>

        <div class="pagination" id="pagination-controls" style="display: flex; justify-content: flex-end; padding: 1rem; gap: 0.5rem; align-items: center; margin-top: 1rem;">
             <!-- Controls injected by JS -->
        </div>
    `;
};
