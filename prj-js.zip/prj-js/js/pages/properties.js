import { formatCurrency, filterData, sortData, paginateData, exportToCSV } from '../utils.js';

export const PropertiesPage = async () => {
    // 1. Fetch data
    const allProperties = await window.app.apiService.get('mock/properties');

    // 2. Local State
    let state = {
        query: '',
        typeFilter: '',
        sortKey: '',
        sortDir: 'asc',
        currentPage: 1,
        pageSize: 5
    };

    // 3. Render Helper (returns HTML string)
    const renderTableRows = () => {
        // Filter
        let data = filterData(allProperties, state.query, ['title', 'city', 'type']);
        if (state.typeFilter) {
            data = data.filter(p => p.type.toLowerCase() === state.typeFilter.toLowerCase());
        }

        // Sort
        data = sortData(data, state.sortKey, state.sortDir);

        // Paginate
        const totalPages = Math.ceil(data.length / state.pageSize) || 1;
        if (state.currentPage > totalPages) state.currentPage = 1;

        const paginatedData = paginateData(data, state.currentPage, state.pageSize);

        // Update Table Body
        const tbody = document.getElementById('properties-tbody');
        if (tbody) {
            tbody.innerHTML = paginatedData.map(p => `
                <tr>
                    <td>#${p.id}</td>
                    <td><div style="width: 50px; height: 35px; background: #eee; border-radius: 4px; display:flex; align-items:center; justify-content:center;"><i class="fa-solid fa-image" style="color:#ccc"></i></div></td>
                    <td>${p.title}</td>
                    <td>${p.city}</td>
                    <td><span style="padding: 4px 8px; background: #e8f4fd; color: var(--primary-color); border-radius: 12px; font-size: 0.85rem;">${p.type}</span></td>
                    <td>${formatCurrency(p.price)}</td>
                    <td>
                        <button class="icon-btn" onclick="window.location.hash='#/properties/${p.id}'" title="View"><i class="fa-solid fa-eye"></i></button>
                        <button class="icon-btn" onclick="window.location.hash='#/properties/${p.id}/edit'" title="Edit"><i class="fa-solid fa-pen-to-square"></i></button>
                        <button class="icon-btn delete-btn" data-id="${p.id}" style="color: #e74c3c;" title="Delete"><i class="fa-solid fa-trash"></i></button>
                    </td>
                </tr>
            `).join('');

            // Re-attach delete listeners
            tbody.querySelectorAll('.delete-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = e.target.closest('button').dataset.id;
                    if (confirm('Delete property?')) {
                        window.app.apiService.deleteProperty(id).then(() => window.app.router.resolve());
                    }
                });
            });
        }

        // Update Pagination Controls
        const paginationContainer = document.getElementById('pagination-controls');
        if (paginationContainer) {
            paginationContainer.innerHTML = `
                <button class="icon-btn" id="prev-page" ${state.currentPage === 1 ? 'disabled' : ''}><i class="fa-solid fa-chevron-left"></i></button>
                <span style="margin: 0 10px;">Page ${state.currentPage} of ${totalPages}</span>
                <button class="icon-btn" id="next-page" ${state.currentPage === totalPages ? 'disabled' : ''}><i class="fa-solid fa-chevron-right"></i></button>
            `;

            document.getElementById('prev-page').onclick = () => { if (state.currentPage > 1) { state.currentPage--; renderTableRows(); } };
            document.getElementById('next-page').onclick = () => { if (state.currentPage < totalPages) { state.currentPage++; renderTableRows(); } };
        }
    };

    // 4. Initial Render
    // We defer binding events until after return using setTimeout
    setTimeout(() => {
        // Bind Filters
        const searchInput = document.getElementById('search-input');
        const typeSelect = document.getElementById('type-select');
        const sortSelect = document.getElementById('sort-select');
        const exportBtn = document.getElementById('export-btn');

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                state.query = e.target.value;
                state.currentPage = 1;
                renderTableRows();
            });
        }
        if (typeSelect) {
            typeSelect.addEventListener('change', (e) => {
                state.typeFilter = e.target.value;
                state.currentPage = 1;
                renderTableRows();
            });
        }
        if (sortSelect) {
            sortSelect.addEventListener('change', (e) => {
                const parts = e.target.value.split('-');
                if (parts.length === 2) {
                    state.sortKey = parts[0];
                    state.sortDir = parts[1];
                } else {
                    state.sortKey = '';
                }
                renderTableRows();
            });
        }

        if (exportBtn) {
            exportBtn.onclick = () => {
                // Export currently filtered data or all data? Usually filtered.
                let data = filterData(allProperties, state.query, ['title', 'city', 'type']);
                if (state.typeFilter) data = data.filter(p => p.type.toLowerCase() === state.typeFilter.toLowerCase());
                data = sortData(data, state.sortKey, state.sortDir);
                exportToCSV(data, 'properties_export.csv');
            }
        }

        // Initial Table Paint
        renderTableRows();
    }, 0);

    return `
        <div class="page-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
            <h1>${window.app.i18n.t('nav.properties')}</h1>
            <div style="display: flex; gap: 10px;">
                <button class="btn-secondary" id="export-btn">
                    <i class="fa-solid fa-file-csv"></i> Export CSV
                </button>
                <button class="btn-primary" onclick="window.location.hash='#/properties/new'">
                    <i class="fa-solid fa-plus"></i> New Property
                </button>
            </div>
        </div>
        
        <div class="filters-bar" style="background: white; padding: 1rem; border-radius: 8px; margin-bottom: 1rem; display: flex; gap: 1rem; flex-wrap: wrap;">
            <input type="text" id="search-input" placeholder="Search title, city..." style="padding: 8px; border: 1px solid #ddd; border-radius: 4px; flex: 1;">
            <select id="type-select" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                <option value="">All Types</option>
                <option value="apartment">Apartment</option>
                <option value="house">House</option>
            </select>
            <select id="sort-select" style="padding: 8px; border: 1px solid #ddd; border-radius: 4px;">
                <option value="">Default Sort</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="title-asc">Title: A-Z</option>
            </select>
        </div>

        <div class="table-container animate-fade-in">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>City</th>
                        <th>Type</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="properties-tbody">
                   <!-- Rows injected by JS -->
                </tbody>
            </table>
            
            <div class="pagination" id="pagination-controls" style="display: flex; justify-content: flex-end; padding: 1rem; gap: 0.5rem; align-items: center;">
                <!-- Controls injected by JS -->
            </div>
        </div>
    `;
};
