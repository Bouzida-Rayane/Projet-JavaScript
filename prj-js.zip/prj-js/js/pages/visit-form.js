import { formatDate } from '../utils.js';

export const VisitFormPage = async (id) => {
    const isEdit = !!id;
    let visit = { property: '', client: '', agent: '', date: '', status: 'Scheduled' };

    if (isEdit) {
        visit = await window.app.apiService.getVisitById(id) || visit;
    }

    return `
        <div class="page-header" style="margin-bottom: 2rem;">
            <h1>${isEdit ? 'Edit Visit' : 'Schedule Visit'}</h1>
            <a href="#/visits" style="text-decoration: none; color: var(--text-muted);"><i class="fa-solid fa-arrow-left"></i> Back to list</a>
        </div>

        <div class="card animate-fade-in" style="background: white; padding: 2rem; border-radius: 12px; max-width: 800px;">
            <form id="visit-form">
                <div class="form-group">
                    <label>Property</label>
                    <input type="text" name="property" value="${visit.property}" placeholder="e.g. Lovely Apt #1" required>
                </div>
                
                <div class="form-group">
                    <label>Client</label>
                     <input type="text" name="client" value="${visit.client}" placeholder="e.g. John Doe" required>
                </div>
                
                <div class="form-group">
                    <label>Agent</label>
                     <input type="text" name="agent" value="${visit.agent}" placeholder="e.g. Agent Smith" required>
                </div>

                <div class="form-group">
                    <label>Date & Time</label>
                    <input type="datetime-local" name="date" value="${visit.date}" required>
                </div>
                
                <div class="form-group">
                    <label>Status</label>
                    <select name="status">
                        <option value="Scheduled" ${visit.status === 'Scheduled' ? 'selected' : ''}>Scheduled</option>
                        <option value="Completed" ${visit.status === 'Completed' ? 'selected' : ''}>Completed</option>
                        <option value="Cancelled" ${visit.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
                    </select>
                </div>

                <div class="form-actions" style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button type="submit" class="btn-primary">${window.app.i18n.t('common.save')}</button>
                    <button type="button" class="btn-secondary" onclick="window.history.back()" style="padding: 10px 20px; border: 1px solid var(--border-color); background: white; border-radius: 6px; cursor: pointer;">${window.app.i18n.t('common.cancel')}</button>
                </div>
            </form>
        </div>
    `;
};

// Handle Form Submission
setTimeout(() => {
    document.addEventListener('submit', async (e) => {
        if (e.target && e.target.id === 'visit-form') {
            e.preventDefault();
            const form = e.target;

            const visit = {
                id: window.location.hash.includes('edit') ? window.location.hash.split('/')[2] : null,
                property: form.querySelector('input[name="property"]').value,
                client: form.querySelector('input[name="client"]').value,
                agent: form.querySelector('input[name="agent"]').value,
                date: form.querySelector('input[name="date"]').value,
                status: form.querySelector('select[name="status"]').value,
            };

            await window.app.apiService.saveVisit(visit);
            window.location.hash = '#/visits';
        }
    });
}, 0);
