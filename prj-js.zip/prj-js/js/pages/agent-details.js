export const AgentDetailsPage = async (id) => {
    let agent = { name: 'Agent', email: '', phone: '', website: '', company: { name: '' }, address: { street: '', city: '' } };

    try {
        const fetchedAgent = await window.app.apiService.getAgentById(id);
        if (fetchedAgent) agent = fetchedAgent;
    } catch (e) {
        console.error('Error fetching agent', e);
    }

    return `
        <div class="page-header" style="margin-bottom: 2rem;">
            <div>
                <a href="#/agents" style="text-decoration: none; color: var(--text-muted); display: inline-flex; align-items: center; gap: 5px; margin-bottom: 10px;">
                    <i class="fa-solid fa-arrow-left"></i> Back to agents
                </a>
                <h1>Agent Profile</h1>
            </div>
        </div>

        <div class="card animate-fade-in" style="background: white; padding: 0; border-radius: 12px; max-width: 800px; overflow: hidden;">
            <div style="background: var(--primary-color); padding: 3rem 2rem; color: white; text-align: center;">
                <div style="width: 100px; height: 100px; background: white; color: var(--primary-color); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: bold; font-size: 2.5rem; margin: 0 auto 1rem;">
                    ${agent.name.charAt(0)}
                </div>
                <h2 style="margin: 0;">${agent.name}</h2>
                <p style="opacity: 0.9;">${agent.company.name}</p>
            </div>
            
            <div style="padding: 2rem;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div>
                        <h3 style="border-bottom: 1px solid #eee; padding-bottom: 0.5rem; margin-bottom: 1rem;">Contact Info</h3>
                        <div style="margin-bottom: 1rem;">
                            <label style="color: var(--text-muted); font-size: 0.85rem;">Email</label>
                            <div><i class="fa-solid fa-envelope" style="color: var(--secondary-color);"></i> ${agent.email}</div>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="color: var(--text-muted); font-size: 0.85rem;">Phone</label>
                            <div><i class="fa-solid fa-phone" style="color: var(--secondary-color);"></i> ${agent.phone}</div>
                        </div>
                        <div style="margin-bottom: 1rem;">
                            <label style="color: var(--text-muted); font-size: 0.85rem;">Website</label>
                            <div><i class="fa-solid fa-globe" style="color: var(--secondary-color);"></i> ${agent.website}</div>
                        </div>
                    </div>
                    
                    <div>
                         <h3 style="border-bottom: 1px solid #eee; padding-bottom: 0.5rem; margin-bottom: 1rem;">Address</h3>
                         <div style="margin-bottom: 1rem;">
                            <label style="color: var(--text-muted); font-size: 0.85rem;">Street</label>
                            <div>${agent.address.street}</div>
                        </div>
                         <div style="margin-bottom: 1rem;">
                            <label style="color: var(--text-muted); font-size: 0.85rem;">City</label>
                            <div>${agent.address.city}</div>
                        </div>
                    </div>
                </div>

                <div style="margin-top: 2rem; padding-top: 2rem; border-top: 1px solid #eee;">
                    <button class="btn-primary" onclick="alert('Message sent to ' + '${agent.name}')"><i class="fa-solid fa-paper-plane"></i> Send Message</button>
                </div>
            </div>
        </div>
    `;
};
