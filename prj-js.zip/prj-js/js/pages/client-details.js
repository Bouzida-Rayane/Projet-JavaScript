import { formatCurrency } from '../utils.js';

export const ClientDetailsPage = async (id) => {
    let client = null;
    try {
        client = await window.app.apiService.getClientById(id);
    } catch (e) {
        console.error('Error fetching client', e);
    }

    if (!client) {
        return `
            <div class="page-header">
                <h1>Client Not Found</h1>
                <a href="#/clients">Back to Clients</a>
            </div>
        `;
    }

    return `
        <div class="page-header" style="margin-bottom: 2rem;">
            <div>
                <a href="#/clients" style="text-decoration: none; color: var(--text-muted); display: inline-flex; align-items: center; gap: 5px; margin-bottom: 10px;">
                    <i class="fa-solid fa-arrow-left"></i> Back to clients
                </a>
                <h1>Client Profile</h1>
            </div>
            <div>
                <button class="btn-primary" onclick="window.location.hash='#/clients/${client.id}/edit'">
                    <i class="fa-solid fa-pen-to-square"></i> Edit Client
                </button>
            </div>
        </div>

        <div class="card animate-fade-in" style="background: white; padding: 0; border-radius: 12px; max-width: 800px; overflow: hidden; display: flex; flex-direction: column;">
            <div style="background: var(--primary-color); padding: 3rem 2rem; color: white; text-align: center;">
                <img src="${client.avatar}" style="width: 100px; height: 100px; border-radius: 50%; border: 4px solid white; object-fit: cover; margin-bottom: 1rem;">
                <h2 style="margin: 0;">${client.first_name} ${client.last_name}</h2>
                <p style="opacity: 0.9;">${client.email}</p>
                 <span style="display:inline-block; margin-top: 10px; padding: 4px 12px; background: rgba(255,255,255,0.2); border-radius: 20px; font-size: 0.9rem;">
                    ${client.status}
                </span>
            </div>
            
            <div style="padding: 2rem;">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
                    <div>
                        <h3 style="border-bottom: 1px solid #eee; padding-bottom: 0.5rem; margin-bottom: 1rem;">Financials</h3>
                        <div style="margin-bottom: 1rem;">
                            <label style="color: var(--text-muted); font-size: 0.85rem;">Budget</label>
                            <div style="font-size: 1.2rem; font-weight: bold; color: var(--secondary-color);">${formatCurrency(client.budget)}</div>
                        </div>
                    </div>
                    
                    <div>
                         <h3 style="border-bottom: 1px solid #eee; padding-bottom: 0.5rem; margin-bottom: 1rem;">Agent</h3>
                         <div style="margin-bottom: 1rem;">
                            <label style="color: var(--text-muted); font-size: 0.85rem;">Assigned To</label>
                            <div>${client.assigned_agent_id ? ('Agent #' + client.assigned_agent_id) : 'Unassigned'}</div>
                        </div>
                    </div>
                </div>

                <div style="margin-top: 2rem; padding-top: 2rem; border-top: 1px solid #eee; display: flex; gap: 1rem;">
                    <button class="btn-primary" onclick="alert('Email sent to ' + '${client.first_name}')"><i class="fa-solid fa-envelope"></i> Send Email</button>
                    <button class="btn-primary" style="background: white; color: var(--text-color); border: 1px solid #ddd;" onclick="alert('Calling ' + '${client.first_name}...')"><i class="fa-solid fa-phone"></i> Call</button>
                </div>
            </div>
        </div>
    `;
};
