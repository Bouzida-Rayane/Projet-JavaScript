import { formatCurrency } from '../utils.js';

export const DashboardPage = async () => {
    const stats = await window.app.apiService.getMockStats();

    return `
        <div class="dashboard-page animate-fade-in">
            <header style="margin-bottom: 2rem; display: flex; justify-content: space-between; align-items: flex-end;">
                <div>
                    <h1>${window.app.i18n.t('nav.dashboard')}</h1>
                    <p style="color: var(--text-muted)">Welcome back, ${window.app?.auth?.user?.name || 'User'}</p>
                </div>
                <button class="btn-primary" onclick="window.app.apiService.exportData()">
                    <i class="fa-solid fa-download"></i> Export Data
                </button>
            </header>
            
            <!-- KPI Cards -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon" style="background: rgba(46, 204, 113, 0.1); color: #27ae60;">
                        <i class="fa-solid fa-check"></i>
                    </div>
                    <div>
                        <h3>${stats.salesCount}</h3>
                        <p style="color: var(--text-muted)">Sold this month</p>
                    </div>
                </div>
                 <div class="stat-card">
                    <div class="stat-icon" style="background: rgba(241, 196, 15, 0.1); color: #f39c12;">
                        <i class="fa-solid fa-house"></i>
                    </div>
                    <div>
                        <h3>${stats.totalProperties}</h3>
                        <p style="color: var(--text-muted)">Available Properties</p>
                    </div>
                </div>
                 <div class="stat-card">
                    <div class="stat-icon" style="background: rgba(52, 152, 219, 0.1); color: #2980b9;">
                        <i class="fa-solid fa-users"></i>
                    </div>
                    <div>
                        <h3>${stats.activeClients}</h3>
                        <p style="color: var(--text-muted)">Active Clients</p>
                    </div>
                </div>
                 <div class="stat-card">
                    <div class="stat-icon" style="background: rgba(155, 89, 182, 0.1); color: #8e44ad;">
                        <i class="fa-solid fa-coins"></i>
                    </div>
                    <div>
                        <h3>${formatCurrency(stats.monthlyRevenue)}</h3>
                        <p style="color: var(--text-muted)">Total Commission</p>
                    </div>
                </div>
            </div>
            
            <!-- Charts Section Row 1 -->
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
                <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: var(--shadow-sm);">
                    <h3>Revenue Trend</h3>
                    <div style="height: 300px;"><canvas id="revenueChart"></canvas></div>
                </div>
                <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: var(--shadow-sm);">
                    <h3>Property Types</h3>
                    <div style="height: 300px;"><canvas id="typeChart"></canvas></div>
                </div>
            </div>

            <!-- Charts Section Row 2 -->
             <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1.5rem;">
                <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: var(--shadow-sm);">
                    <h3>Agent Performance</h3>
                    <div style="height: 250px;"><canvas id="agentChart"></canvas></div>
                </div>
                <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: var(--shadow-sm);">
                    <h3>Client Distribution</h3>
                    <div style="height: 250px;"><canvas id="clientChart"></canvas></div>
                </div>
                <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: var(--shadow-sm);">
                    <h3>Visit Status</h3>
                    <div style="height: 250px;"><canvas id="visitChart"></canvas></div>
                </div>
            </div>
        </div>
    `;
};

// Initialize Charts after render
export const initDashboardCharts = () => {
    // 1. Revenue (Line)
    const revenueCtx = document.getElementById('revenueChart');
    if (revenueCtx) {
        new Chart(revenueCtx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Revenue ($)',
                    data: [12000, 19000, 3000, 5000, 2000, 30000],
                    borderColor: '#1a2a6c',
                    backgroundColor: 'rgba(26, 42, 108, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: { maintainAspectRatio: false }
        });
    }

    // 2. Property Types (Doughnut)
    const typeCtx = document.getElementById('typeChart');
    if (typeCtx) {
        new Chart(typeCtx, {
            type: 'doughnut',
            data: {
                labels: ['Apartment', 'House', 'Villa', 'Office'],
                datasets: [{
                    data: [35, 25, 20, 20],
                    backgroundColor: ['#1a2a6c', '#b21f1f', '#fdbb2d', '#95a5a6']
                }]
            },
            options: { maintainAspectRatio: false }
        });
    }

    // 3. Agent Performance (Bar)
    const agentCtx = document.getElementById('agentChart');
    if (agentCtx) {
        new Chart(agentCtx, {
            type: 'bar',
            data: {
                labels: ['John', 'Jane', 'Mike', 'Sarah'],
                datasets: [{
                    label: 'Sales',
                    data: [12, 19, 3, 5],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.7)',
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 206, 86, 0.7)',
                        'rgba(75, 192, 192, 0.7)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: { beginAtZero: true }
                },
                maintainAspectRatio: false
            }
        });
    }

    // 4. Client Distribution (Pie)
    const clientCtx = document.getElementById('clientChart');
    if (clientCtx) {
        new Chart(clientCtx, {
            type: 'pie',
            data: {
                labels: ['Leads', 'Active', 'Closed'],
                datasets: [{
                    data: [50, 30, 20],
                    backgroundColor: ['#ffa502', '#2ed573', '#ff4757']
                }]
            },
            options: { maintainAspectRatio: false }
        });
    }

    // 5. Visit Status (PolarArea)
    const visitCtx = document.getElementById('visitChart');
    if (visitCtx) {
        new Chart(visitCtx, {
            type: 'polarArea',
            data: {
                labels: ['Scheduled', 'Completed', 'Cancelled', 'No Show'],
                datasets: [{
                    data: [11, 16, 7, 3],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.5)',
                        'rgba(75, 192, 192, 0.5)',
                        'rgba(255, 205, 86, 0.5)',
                        'rgba(201, 203, 207, 0.5)'
                    ]
                }]
            },
            options: { maintainAspectRatio: false }
        });
    }
};
