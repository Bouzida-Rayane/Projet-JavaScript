export const PropertyFormPage = async (id) => {
    const isEdit = !!id;
    let property = { title: '', type: 'apartment', price: 0, city: '', description: '' };

    if (isEdit) {
        property = await window.app.apiService.getPropertyById(id) || property;
    }

    return `
        <div class="page-header" style="margin-bottom: 2rem;">
            <h1>${isEdit ? 'Edit Property' : 'New Property'}</h1>
            <a href="#/properties" style="text-decoration: none; color: var(--text-muted);"><i class="fa-solid fa-arrow-left"></i> Back to list</a>
        </div>

        <div class="card animate-fade-in" style="background: white; padding: 2rem; border-radius: 12px; max-width: 800px;">
            <form id="property-form">
                <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title" value="${property.title}" required>
                </div>
                
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <div class="form-group">
                        <label>Type</label>
                        <select name="type">
                            <option value="Apartment" ${property.type === 'Apartment' ? 'selected' : ''}>Apartment</option>
                            <option value="House" ${property.type === 'House' ? 'selected' : ''}>House</option>
                            <option value="Villa" ${property.type === 'Villa' ? 'selected' : ''}>Villa</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Price ($)</label>
                        <input type="number" name="price" value="${property.price}" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>City</label>
                    <input type="text" name="city" value="${property.city}" required>
                </div>
                
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" rows="4" style="width: 100%; padding: 12px; border: 1px solid var(--border-color); border-radius: 8px;">${property.description}</textarea>
                </div>

                <div class="form-actions" style="display: flex; gap: 1rem; margin-top: 2rem;">
                    <button type="submit" class="btn-primary">${window.app.i18n.t('common.save')}</button>
                    <button type="button" class="btn-secondary" onclick="window.history.back()" style="padding: 10px 20px; border: 1px solid var(--border-color); background: white; border-radius: 6px; cursor: pointer;">${window.app.i18n.t('common.cancel')}</button>
                </div>
            </form>
        </div>
    `;
};

// Handle Form Submission
setTimeout(() => {
    document.addEventListener('submit', async (e) => {
        if (e.target && e.target.closest('#property-form')) {
            e.preventDefault();
            const form = e.target;

            const property = {
                id: window.location.hash.includes('edit') ? window.location.hash.split('/')[2] : null,
                title: form.querySelector('input[name="title"]').value,
                type: form.querySelector('select[name="type"]').value,
                price: Number(form.querySelector('input[name="price"]').value),
                city: form.querySelector('input[name="city"]').value,
                description: form.querySelector('textarea[name="description"]').value
            };

            await window.app.apiService.saveProperty(property);
            window.location.hash = '#/properties';
        }
    });
}, 0);
